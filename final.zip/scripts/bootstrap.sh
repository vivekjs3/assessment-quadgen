#!/usr/bin/env bash
set -euo pipefail

# Configuration
CLUSTER_NAME="kind-jenkins"
REGISTRY_NAME="kind-registry"
REGISTRY_PORT="5001"

echo "================================================================="
echo "  🚀 Starting Kubernetes & Jenkins CI/CD Setup"
echo "  Supports: Local Host (Mac/Linux/Win) & Proxmox (VM / LXC / Baremetal)"
echo "================================================================="

# 0. Prerequisites Auto-Checker & Installer (Runs on any Linux machine)
check_and_install_prereqs() {
  echo "🔍 Checking system prerequisites..."

  # Check curl
  if ! command -v curl &>/dev/null; then
    echo "📦 Installing curl..."
    if command -v apt-get &>/dev/null; then
      sudo apt-get update -y && sudo apt-get install -y curl
    elif command -v dnf &>/dev/null; then
      sudo dnf install -y curl
    elif command -v yum &>/dev/null; then
      sudo yum install -y curl
    fi
  fi

  # Check make
  if ! command -v make &>/dev/null; then
    echo "📦 Installing make..."
    if command -v apt-get &>/dev/null; then
      sudo apt-get update -y && sudo apt-get install -y make
    elif command -v dnf &>/dev/null; then
      sudo dnf install -y make
    elif command -v yum &>/dev/null; then
      sudo yum install -y make
    fi
  fi

  # Check Docker
  if ! command -v docker &>/dev/null; then
    echo "📦 Docker not found. Installing Docker Engine..."
    if command -v apt-get &>/dev/null; then
      sudo apt-get update -y && sudo apt-get install -y docker.io
    elif command -v dnf &>/dev/null; then
      sudo dnf install -y docker
    else
      curl -fsSL https://get.docker.com | sh
    fi
    sudo systemctl enable --now docker || true
  fi

  # Ensure Docker service is running
  if ! docker info &>/dev/null; then
    echo "🔄 Starting Docker service..."
    sudo systemctl start docker || service docker start || true
    sleep 3
  fi

  # Check kubectl
  if ! command -v kubectl &>/dev/null; then
    echo "📦 kubectl not found. Downloading kubectl v1.29.2..."
    curl -LO "https://dl.k8s.io/release/v1.29.2/bin/linux/amd64/kubectl"
    chmod +x kubectl
    sudo mv kubectl /usr/local/bin/kubectl || mv kubectl ~/.local/bin/kubectl
  fi

  # Check KinD
  if ! command -v kind &>/dev/null; then
    echo "📦 KinD not found. Downloading KinD v0.22.0..."
    curl -Lo ./kind_bin "https://kind.sigs.k8s.io/dl/v0.22.0/kind-linux-amd64"
    chmod +x ./kind_bin
    sudo mv ./kind_bin /usr/local/bin/kind || mv ./kind_bin ~/.local/bin/kind || true
  fi

  echo "✅ All prerequisites (Docker, kubectl, KinD, curl, make) are installed & ready!"
}

check_and_install_prereqs

# Detect IP address (local or Proxmox host IP)
HOST_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")
[ -z "$HOST_IP" ] && HOST_IP="127.0.0.1"

# 1. Start Local Docker Registry (Zero cost container registry)
if [ "$(docker inspect -f '{{.State.Running}}' "${REGISTRY_NAME}" 2>/dev/null || true)" != 'true' ]; then
  echo "📦 Creating and starting local container registry '${REGISTRY_NAME}' on port ${REGISTRY_PORT}..."
  docker run -d --restart=always -p "0.0.0.0:${REGISTRY_PORT}:5000" --network bridge --name "${REGISTRY_NAME}" registry:2 || true
else
  echo "✅ Local container registry '${REGISTRY_NAME}' is already running."
fi

# 2. Create KinD Cluster if not present
if ! kind get clusters 2>/dev/null | grep -q "^${CLUSTER_NAME}$"; then
  echo "☸️ Creating KinD cluster '${CLUSTER_NAME}' with 0.0.0.0 external LAN bindings..."
  kind create cluster --name "${CLUSTER_NAME}" --config kind/kind-config.yaml
else
  echo "✅ KinD cluster '${CLUSTER_NAME}' already exists."
fi

# 3. Connect Local Registry to KinD Docker Network
if [ "$(docker inspect -f='{{json .NetworkSettings.Networks.kind}}' "${REGISTRY_NAME}")" = 'null' ]; then
  echo "🔗 Connecting '${REGISTRY_NAME}' to KinD network..."
  docker network connect "kind" "${REGISTRY_NAME}" || true
fi

# 4. Apply containerd Local Registry Hosting ConfigMap
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  name: local-registry-hosting
  namespace: kube-public
data:
  localRegistryHosting.v1: |
    host: "localhost:${REGISTRY_PORT}"
    help: "https://kind.sigs.k8s.io/docs/user/local-registry/"
EOF

# 5. Create Namespaces and Jenkins ConfigMaps (JCasC + Plugins)
echo "📁 Applying Namespaces & Scoped RBAC..."
kubectl apply -f k8s/namespaces.yaml
kubectl apply -f k8s/jenkins-rbac.yaml

# Create ConfigMap from JCasC files
kubectl create configmap jenkins-casc-config --from-file=jenkins.yaml=jcasc/jenkins.yaml -n jenkins --dry-run=client -o yaml | kubectl apply -f -
kubectl create configmap jenkins-plugins-config --from-file=plugins.txt=jcasc/plugins.txt -n jenkins --dry-run=client -o yaml | kubectl apply -f -

# 6. Deploy Jenkins Controller & Services & Sample App Initial Deployment
echo "🚀 Deploying Jenkins Controller, Services & Sample App..."
kubectl apply -f k8s/jenkins-service.yaml
kubectl apply -f k8s/jenkins-deployment.yaml
kubectl apply -f k8s/sample-app/deployment.yaml

echo "⏳ Waiting for Jenkins Controller to become ready..."
kubectl rollout status deployment/jenkins -n jenkins --timeout=300s

echo ""
echo "================================================================="
echo "  🎉 CI/CD Platform is Ready!"
echo "================================================================="
echo "  Local Access:        http://localhost:8080"
echo "  Proxmox / LAN Access:http://${HOST_IP}:8080"
echo "  Credentials (Admin): admin / adminpassword123"
echo "  Credentials (Dev):   developer / devpassword123"
echo "  Credentials (Audit): auditor / auditpassword123"
echo ""
echo "  Pre-seeded Pipelines (Automated Ephemeral Agent Pods):"
echo "    1. node-microservice-pipeline   (Node.js 20)"
echo "    2. python-microservice-pipeline (Python 3.11)"
echo "    3. java-microservice-pipeline   (Java 17 / Maven)"
echo "================================================================="

